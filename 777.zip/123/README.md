# DDoS-Script
 A script written in perl for ddos perl with automatic detection of open and vulnerable port that gives up to 1.5 gb packages / s
How to use? 
Windows : install strawberryperl , open command prompt in the file location then write perl cqHack.pl 69.69.69.69
Linux : apt-get install perl the run the command such like windows
Enjoy D:
